package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Order;
import model.Employee;
import model.Movie;

public class MovieDao {

	
	public List<Movie> getMovies() {
		
		/*
		 * The students code to fetch data from the database will be written here
		 * Query to fetch details of all the movies has to be implemented
		 * Each record is required to be encapsulated as a "Movie" class object and added to the "movies" List
		 */

		List<Movie> movies = new ArrayList<Movie>();
				
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");			
			String SQL = "SELECT Id FROM movie";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next())
            {
            	movies.add(getMovie(rs.getInt("Id")));
            }
            return movies;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
	
	public Movie getMovie(int movieID) {

		/*
		 * The students code to fetch data from the database based on "movieID" will be written here
		 * movieID, which is the Movie's ID who's details have to be fetched, is given as method parameter
		 * The record is required to be encapsulated as a "Movie" class object
		 */
		Movie movie = new Movie();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");			
			String SQL = "SELECT * FROM movie where Id like \'%" + movieID + "%\'";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next())
            {
            	movie.setMovieID(movieID);
            	movie.setMovieName(rs.getString("Name"));
            	movie.setMovieType(rs.getString("Type"));
            	movie.setDistFee(rs.getInt("DistrFee"));
            	movie.setNumCopies(rs.getInt("NumCopies"));
            	movie.setRating(rs.getInt("Rating"));
            	return movie;

            }			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return null;
	}
	
	public String addMovie(Movie movie) {

		/*
		 * All the values of the add movie form are encapsulated in the movie object.
		 * These can be accessed by getter methods (see Employee class in model package).
		 * e.g. movieName can be accessed by movie.getMovieName() method.
		 * The sample code returns "success" by default.
		 * You need to handle the database insertion of the movie details and return "success" or "failure" based on result of the database insertion.
		 */

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");		
			String SQL = "INSERT INTO `movie`(Id,Name,Type,Rating,DistrFee,NumCopies) VALUE (?,?,?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(SQL);
			pstmt.setInt(1, movie.getMovieID());
			pstmt.setString(2, movie.getMovieName());
			pstmt.setString(3, movie.getMovieType());
			pstmt.setInt(4, movie.getRating());
			pstmt.setInt(5, movie.getDistFee());
			pstmt.setInt(6, movie.getNumCopies());
			pstmt.executeUpdate();
			
			return "success";
			
		} catch (Exception e) {
			e.printStackTrace();
			return "failure";
		}

	}
	
	public int findMovieId(Movie movie)
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");
			
			String SQLforMaxId = "SELECT MAX(Id) AS max FROM `movie`";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(SQLforMaxId);
			int maxId = 0;
            while (rs.next())
            {
            	maxId = rs.getInt("max");
            }
            return maxId + 1;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
	}
	
	public String editMovie(Movie movie) {
		/*
		 * All the values of the edit movie form are encapsulated in the movie object.
		 * These can be accessed by getter methods (see Movie class in model package).
		 * e.g. movieName can be accessed by movie.getMovieName() method.
		 * The sample code returns "success" by default.
		 * You need to handle the database update and return "success" or "failure" based on result of the database update.
		 */

		String Name = movie.getMovieName();
	    String Type = movie.getMovieType();
	    int Rating = movie.getRating();
	    int NumCopies = movie.getNumCopies();
		int DistrFee = movie.getDistFee();
		int Id = movie.getMovieID();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");
			Statement stmt = con.createStatement();
			
			String SQL = "UPDATE `movie` SET Name = \'" + Name +
					"\', Type = \'" + Type + "\', Rating = \'" + Rating + "\', DistrFee = \'" + DistrFee +
					"\', NumCopies = \'" + NumCopies + "\' WHERE Id like \'" + Id + "\'";
			
			stmt.executeUpdate(SQL);
			return "success";
			
		} catch (Exception e) {
			e.printStackTrace();
			return "failure";
		}
	}

	public String deleteMovie(int movieID) {
		/*
		 * movieID, which is the Movie's ID which has to be deleted, is given as method parameter
		 * The sample code returns "success" by default.
		 * You need to handle the database deletion and return "success" or "failure" based on result of the database deletion.
		 */

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return "failure";
		}

		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root",
				"root"); Statement stmt = con.createStatement();) {

			String SQL = ("DELETE FROM movie where Id like " + movieID);
			stmt.executeUpdate(SQL);
			return "success";
		} catch (SQLException e) {
			e.printStackTrace();
			return "failure";
		}
	}
	
	
	public List<Movie> getBestsellerMovies() {
		
		/*
		 * The students code to fetch data from the database will be written here
		 * Query to fetch details of the bestseller movies has to be implemented
		 * Each record is required to be encapsulated as a "Movie" class object and added to the "movies" List
		 */
		List<Movie> movies = new ArrayList<Movie>();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return null;
		} 
		
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root",
				"root"); Statement stmt = con.createStatement();) {
			
			String SQL = ("SELECT movie.Id, movie.Name, movie.Type, movie.DistrFee, movie.NumCopies, movie.Rating "
					+ "FROM `movie`, `movieOrder` "
					+ "WHERE movieOrder.MovieId = movie.Id "
					+ "ORDER BY movieOrder.numOrders DESC");
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
	        	
				Movie movie = new Movie();
				int tempId = rs.getInt("movie.Id");
				String tempName = rs.getString("movie.Name");
				String tempType = rs.getString("Movie.Type");
				int distrFee = rs.getInt("movie.DistrFee");
				int numCopies = rs.getInt("NumCopies");
				int rating = rs.getInt("movie.Rating");
				int tempInt = 0;
//				for(int i = 0;i < movies.size(); i++) {
//					if(movies.get(i).getMovieType().equals(temp))
//						tempInt ++;
//				}
				if(tempInt == 0) 
				{
					movie.setMovieID(tempId);
					movie.setMovieName(tempName);
					movie.setMovieType(tempType);
					movie.setDistFee(distrFee);
					movie.setNumCopies(numCopies);
					movie.setRating(rating);
					movies.add(movie);
				}
	        }
			
//			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		
		
		return movies;
	}

	public List<Movie> getSummaryListing(String searchKeyword) {
		
		/*
		 * The students code to fetch data from the database will be written here
		 * Query to fetch details of summary listing of revenue generated by a particular movie or movie type must be implemented
		 * Each record is required to be encapsulated as a "Movie" class object and added to the "movies" ArrayList
		 * Store the revenue generated by an movie in the soldPrice attribute, using setSoldPrice method of each "movie" object
		 */

		List<Movie> movies = new ArrayList<Movie>();
				
		/*Sample data begins*/
		for (int i = 0; i < 6; i++) {
			Movie movie = new Movie();
			movie.setMovieID(1);
			movie.setMovieName("The Godfather");
			movie.setMovieType("Drama");
			movie.setDistFee(10000);
			movie.setNumCopies(3);
			movie.setRating(5);
			movies.add(movie);
		}
		/*Sample data ends*/
		
		return movies;

	}
	
	
	

	public List<Movie> getMovieSuggestions(int customerID) {
		
		/*
		 * The students code to fetch data from the database will be written here
		 * Query to fetch movie suggestions for a customer, indicated by customerID, must be implemented
		 * customerID, which is the Customer's ID for whom the movie suggestions are fetched, is given as method parameter
		 * Each record is required to be encapsulated as a "Movie" class object and added to the "movies" ArrayList
		 */

//		List<Movie> movies = new ArrayList<Movie>();
//		
//		try {
//			Class.forName("com.mysql.cj.jdbc.Driver");
//		} catch (ClassNotFoundException e1) {
//			e1.printStackTrace();
//			return null;
//		}
//
//		// Create a connection to the SQL server and query matches for username and
//		// password
//		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb?useSSL=false", "root", "root"); Statement stmt = con.createStatement();) {
//			String SQL = ("CREATE VIEW PastOrder(CustId, MovieId, MovieType AS SELECT ")
//			
//			String SQL = ("SELECT CustId FROM customer");
//			ResultSet rs = stmt.executeQuery(SQL);
//			while (rs.next()) {
//				movies.add(getCustomer(rs.getInt("CustId")));
//			}
//			rs.close();
//			return movies;
//		} catch (SQLException e) {
//			e.printStackTrace();
			return null;
//		}
		
//		/*Sample data begins*/
//		for (int i = 0; i < 4; i++) {
//			Movie movie = new Movie();
//			movie.setMovieID(1);
//			movie.setMovieName("The Godfather");
//			movie.setMovieType("Drama");
//			movies.add(movie);
//		}
//		/*Sample data ends*/

	}
	
	public List<Movie> getCurrentMovies(String customerID){
		
		/*
		 * The students code to fetch data from the database will be written here
		 * Query to fetch currently hold movie for a customer, indicated by customerID, must be implemented
		 * customerID, which is the Customer's ID for whom currently hold movie are fetched, is given as method parameter
		 * Each record is required to be encapsulated as a "Movie" class object and added to the "movies" ArrayList
		 */
		
		List<Movie> movies = new ArrayList<Movie>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return null;
		} 
		
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root",
				"root"); Statement stmt = con.createStatement();) {
			
			String SQL = ("SELECT movie.ID, movie.Name "
					+ "FROM `account`, `movie`, `rental`, `order` "
					+ "WHERE account.customer = " + customerID + " AND account.Id = rental.AccountID AND rental.OrderID = order.Id"
					+ " AND movie.Id = rental.MovieId AND order.ReturnDate is NULL");
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
            	
				Movie movie = new Movie();
				int tempID = rs.getInt("ID");
				String tempName = rs.getString("Name");
				int tempInt = 0;
				if(tempInt == 0) 
				{
					movie.setMovieID(tempID);
					movie.setMovieName(tempName);
					movies.add(movie);
				}
            }
			
//			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return movies;
		
		
		
	}
	
public List<Movie> getQueueOfMovies(String customerID){
		
		/*
		 * The students code to fetch data from the database will be written here
		 * Query to fetch movie queue for a customer, indicated by customerID, must be implemented
		 * customerID, which is the Customer's ID for whom movie queue are fetched, is given as method parameter
		 * Each record is required to be encapsulated as a "Movie" class object and added to the "movies" ArrayList
		 */

	List<Movie> movies = new ArrayList<Movie>();
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	} catch (ClassNotFoundException e1) {
		e1.printStackTrace();
		return null;
	} 
	
	
	try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root",
			"root"); Statement stmt = con.createStatement();) {
		
		String SQL = ("SELECT movie.ID, movie.Name, movie.Type "
				+ "FROM account, movieq, movie "
				+ "WHERE account.Id = movieq.AccountId AND movieq.movieId = movie.Id AND account.customer = " + customerID);
		ResultSet rs = stmt.executeQuery(SQL);
		while (rs.next()) {
        	
			Movie movie = new Movie();
			int tempID = rs.getInt("ID");
			String tempName = rs.getString("Name");
			String tempType = rs.getString("Type");
			int tempInt = 0;
//			for(int i = 0;i < movies.size(); i++) {
//				if(movies.get(i).getMovieType().equals(temp))
//					tempInt ++;
//			}
			if(tempInt == 0) 
			{
				movie.setMovieID(tempID);
				movie.setMovieName(tempName);
				movie.setMovieType(tempType);
				movies.add(movie);
			}
        }
		
//		
	} catch (SQLException e) {
		e.printStackTrace();
		return null;
	}
	
		return movies;
		
		
		
	}
	
	

//	public List getMoviesBySeller(String sellerID) {
//		
//		/*
//		 * The students code to fetch data from the database will be written here
//		 * Query to fetch movies sold by a given seller, indicated by sellerID, must be implemented
//		 * sellerID, which is the Sellers's ID who's movies are fetched, is given as method parameter
//		 * The bid and order details of each of the movies should also be fetched
//		 * The bid details must have the highest current bid for the movie
//		 * The order details must have the details about the order in which the movie is sold
//		 * Each movie record is required to be encapsulated as a "Movie" class object and added to the "movies" List
//		 * Each bid record is required to be encapsulated as a "Bid" class object and added to the "bids" List
//		 * Each order record is required to be encapsulated as a "Order" class object and added to the "orders" List
//		 * The movies, bids and orders Lists have to be added to the "output" List and returned
//		 */
//
//		List output = new ArrayList();
//		List<Movie> movies = new ArrayList<Movie>();
//		List<Bid> bids = new ArrayList<Bid>();
//		List<Order> orders = new ArrayList<Order>();
//		
//		/*Sample data begins*/
//		for (int i = 0; i < 4; i++) {
//			Movie movie = new Movie();
//			movie.setMovieID(123);
//			movie.setDescription("sample description");
//			movie.setType("BOOK");
//			movie.setName("Sample Book");
//			movies.add(movie);
//			
//			Bid bid = new Bid();
//			bid.setCustomerID("123-12-1234");
//			bid.setBidPrice(120);
//			bids.add(bid);
//			
//			Order order = new Order();
//			order.setMinimumBid(100);
//			order.setBidIncrement(10);
//			order.setOrderID(123);
//			orders.add(order);
//		}
//		/*Sample data ends*/
//		
//		output.add(movies);
//		output.add(bids);
//		output.add(orders);
//		
//		return output;
//	}

	public List<Movie> getMovieTypes() {

		/*
		 * The students code to fetch data from the database will be written here Each
		 * record is required to be encapsulated as a "Movie" class object and added to
		 * the "movies" ArrayList A query to fetch the unique movie types has to be
		 * implemented Each movie type is to be added to the "movie" object using
		 * setType method
		 */

		List<Movie> movies = new ArrayList<Movie>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return null;
		}
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");
				Statement stmt = con.createStatement();) {

			String SQL = ("SELECT Type FROM movie");
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {

				Movie movie = new Movie();
				String temp = rs.getString("Type");
				int tempInt = 0;
				for (int i = 0; i < movies.size(); i++) {
					if (movies.get(i).getMovieType().equals(temp))
						tempInt++;
				}
				if (tempInt == 0) {
					movie.setMovieType(temp);
					movies.add(movie);
				}
			}

//		
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}

		/* Sample data begins */
//	for (int i = 0; i < 6; i++) {
//		Movie movie = new Movie();
//		movie.setMovieType("sss");
//		movies.add(movie);
//	}
		/* Sample data ends */

		return movies;
	}

	public List getMoviesByName(String movieName) {

    	
		/*
		 * The students code to fetch data from the database will be written here
		 * The movieName, which is the movie's name on which the query has to be implemented, is given as method parameter
		 * Query to fetch movies containing movieName in their name has to be implemented
		 * Each movie's corresponding order data also has to be fetched
		 * Each movie record is required to be encapsulated as a "Movie" class object and added to the "movies" List
		 * Each order record is required to be encapsulated as a "Order" class object and added to the "orders" List
		 * The movies and orders Lists are to be added to the "output" List and returned
		 */

		List<Movie> movies = new ArrayList<Movie>();
		
		
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root",
				"root"); Statement stmt = con.createStatement();) {

			String SQL = ("SELECT ID,Name,Type FROM movie WHERE Name LIKE  '%" + movieName +"%'");
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
            	
				Movie movie = new Movie();
				String temp = rs.getString("Name");
				int tempID = rs.getInt("ID");
				String tempType = rs.getString("Type");
				int tempInt = 0;
				for(int i = 0;i < movies.size(); i++) {
					if(movies.get(i).getMovieName().equals(temp))
						tempInt ++;
				}
				if(tempInt == 0) 
				{
					movie.setMovieID(tempID);
					movie.setMovieName(temp);
					movie.setMovieType(tempType);
					movies.add(movie);
				}
            }
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}

		
		return movies;
	}
	
	public List getMoviesByActor(String actorName) {

		/*
		 * The students code to fetch data from the database will be written here The
		 * movieName, which is the movie's name on which the query has to be
		 * implemented, is given as method parameter Query to fetch movies containing
		 * movieName in their name has to be implemented Each movie's corresponding
		 * order data also has to be fetched Each movie record is required to be
		 * encapsulated as a "Movie" class object and added to the "movies" List Each
		 * order record is required to be encapsulated as a "Order" class object and
		 * added to the "orders" List The movies and orders Lists are to be added to the
		 * "output" List and returned
		 */

		List<Movie> movies = new ArrayList<Movie>();

		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");
				Statement stmt = con.createStatement();) {

			String SQL = ("SELECT movie.ID, movie.Name, movie.Type FROM movie, appearedin, actor WHERE actor.name LIKE '%"
					+ actorName + "%' AND " + "appearedin.ActorID = actor.ID AND appearedIn.MovieID = movie.ID");
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {

				Movie movie = new Movie();
				String temp = rs.getString("Name");
				int tempID = rs.getInt("ID");
				String tempType = rs.getString("Type");
				int tempInt = 0;
				for (int i = 0; i < movies.size(); i++) {
					if (movies.get(i).getMovieName().equals(temp))
						tempInt++;
				}
				if (tempInt == 0) {
					movie.setMovieID(tempID);
					movie.setMovieName(temp);
					movie.setMovieType(tempType);
					movies.add(movie);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}

		return movies;
	}
	

	public List getMoviesByType(String movieType) {
		
		/*
		 * The students code to fetch data from the database will be written here
		 * The movieType, which is the movie's type on which the query has to be implemented, is given as method parameter
		 * Query to fetch movies containing movieType as their type has to be implemented
		 * Each movie's corresponding order data also has to be fetched
		 * Each movie record is required to be encapsulated as a "Movie" class object and added to the "movies" List
		 * Each order record is required to be encapsulated as a "Order" class object and added to the "orders" List
		 * The movies and orders Lists are to be added to the "output" List and returned
		 */

		List<Movie> movies = new ArrayList<Movie>();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return null;
		} 
		
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root",
				"root"); Statement stmt = con.createStatement();) {
			
			String SQL = ("SELECT Id, Name, Type "
					+ "From movie "
					+ "WHERE movie.Type = '" + movieType +"'");
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
	        	
				Movie movie = new Movie();
				int tempId = rs.getInt("Id");
				String tempName = rs.getString("Name");
				String tempType = rs.getString("Type");
				int tempInt = 0;
//				for(int i = 0;i < movies.size(); i++) {
//					if(movies.get(i).getMovieType().equals(temp))
//						tempInt ++;
//				}
				if(tempInt == 0) 
				{
					movie.setMovieID(tempId);
					movie.setMovieName(tempName);
					movie.setMovieType(tempType);
					movies.add(movie);
				}
	        }
			
//			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		
		
		return movies;
	}
	
	public List getMovieRentalsByName(String movieName) {
		
		List<Movie> movies = new ArrayList<Movie>();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");
			Statement stmt = con.createStatement();

			String SQL = ("SELECT movie.ID,movie.Name,movie.Type,rental.MovieId FROM `movie`, `rental` WHERE movie.Name LIKE  '%" + movieName +"%' and movie.ID LIKE rental.MovieId");
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				Movie movie = new Movie();
				String temp = rs.getString("Name");
				int tempID = rs.getInt("ID");
				String tempType = rs.getString("Type");
				int tempInt = 0;
				for(int i = 0;i < movies.size(); i++) {
					if(movies.get(i).getMovieName().equals(temp))
						tempInt++;
				}
				if(tempInt == 0) 
				{
					movie.setMovieID(tempID);
					movie.setMovieName(temp);
					movie.setMovieType(tempType);
					movies.add(movie);
				}	
            }
		return movies;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public List getMovieRentalsByCustomer(String customerName) {
		List<Movie> movies = new ArrayList<Movie>();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");
			Statement stmt = con.createStatement();

			String SQL = ("SELECT movie.ID, movie.Name, movie.Type, rental.MovieID, rental.AccountId, rental.MovieID, account.Id, account.Customer, customer.CustId, person.FirstName, person.LastName FROM `movie`, `rental`, `account`, `customer`, `person`" 
					+ "WHERE rental.AccountId = account.Id AND account.Customer = customer.CustId AND rental.MovieID = movie.ID AND person.FirstName LIKE '%" + customerName + "%' OR " + 
					"rental.AccountId = account.Id AND account.Customer = customer.CustId AND rental.MovieID = movie.ID AND person.LastName LIKE '%" + customerName + "%'");
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				Movie movie = new Movie();
				String temp = rs.getString("Name");
				int tempID = rs.getInt("ID");
				String tempType = rs.getString("Type");
				int tempInt = 0;
				for(int i = 0;i < movies.size(); i++) {
					if(movies.get(i).getMovieName().equals(temp))
						tempInt ++;
				}
				if(tempInt == 0) 
				{
					movie.setMovieID(tempID);
					movie.setMovieName(temp);
					movie.setMovieType(tempType);
					movies.add(movie);
				}
            }
		return movies;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	

	public List getMovieRentalsByType(String movieType) {
		
		List<Movie> movies = new ArrayList<Movie>();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");
			Statement stmt = con.createStatement();

			String SQL = ("SELECT movie.Id, movie.Name, movie.Type "
					+ "From `movie`, `rental` "
					+ "WHERE movie.Type = '" + movieType +"' AND rental.MovieId = movie.Id");
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
	        	
				Movie movie = new Movie();
				int tempId = rs.getInt("Id");
				String tempName = rs.getString("Name");
				String tempType = rs.getString("Type");
				int tempInt = 0;

				if(tempInt == 0) 
				{
					movie.setMovieID(tempId);
					movie.setMovieName(tempName);
					movie.setMovieType(tempType);
					movies.add(movie);
				}
	        }
			
			return movies;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	

	public List<Movie> getBestsellersForCustomer() {

		/*
		 * The students code to fetch data from the database will be written here.
		 * Each record is required to be encapsulated as a "Movie" class object and added to the "movies" ArrayList.
		 * Query to get the Best-seller list of movies for a particular customer, indicated by the customerID, has to be implemented
		 * The customerID, which is the customer's ID for whom the Best-seller movies have to be fetched, is given as method parameter
		 * 
		 */
		

		List<Movie> movies = new ArrayList<Movie>();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return null;
		} 
		
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root",
				"132546"); Statement stmt = con.createStatement();) {
			
			String SQL = ("SELECT movie.Id, movie.Name, movie.Type "
					+ "FROM `movie`, `movieOrder` "
					+ "WHERE movieOrder.MovieId = movie.Id "
					+ "ORDER BY movieOrder.numOrders DESC");
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
	        	
				Movie movie = new Movie();
				int tempId = rs.getInt("movie.Id");
				String tempName = rs.getString("movie.Name");
				String tempType = rs.getString("Movie.Type");
				int tempInt = 0;
//				for(int i = 0;i < movies.size(); i++) {
//					if(movies.get(i).getMovieType().equals(temp))
//						tempInt ++;
//				}
				if(tempInt == 0) 
				{
					movie.setMovieID(tempId);
					movie.setMovieName(tempName);
					movie.setMovieType(tempType);
					movies.add(movie);
				}
	        }
			
//			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		
		
		return movies;
	}
}
