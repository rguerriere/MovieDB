package dao;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import model.Customer;
import model.Customer;

import java.util.stream.IntStream;

public class CustomerDao {
	/*
	 * This class handles all the database operations related to the customer table
	 */

	/**
	 * @param String searchKeyword
	 * @return ArrayList<Customer> object
	 */
	public List<Customer> getCustomers() {
		/*
		 * This method fetches one or more customers and returns it as an ArrayList
		 */

		List<Customer> customers = new ArrayList<Customer>();
		
		/*
		 * The students code to fetch data from the database will be written here Each
		 * record is required to be encapsulated as a "Customer" class object and added
		 * to the "customers" List
		 */
		
		//Necessary for jdbc driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return null;
		} 
		
		//Create a connection to the SQL server and query matches for username and password
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb?useSSL=false", "root", "root");
                Statement stmt = con.createStatement();) {
            String SQL = ("SELECT CustId FROM customer");
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
            	customers.add(getCustomer(rs.getInt("CustId")));       	
            }
            rs.close();
            return customers;
            } catch (SQLException e) {
                e.printStackTrace();
                return null;
            }
	}


	public Customer getHighestRevenueCustomer() {
		/*
		 * This method fetches the customer who generated the highest total revenue and returns it
		 * The students code to fetch data from the database will be written here
		 * The customer record is required to be encapsulated as a "Customer" class object
		 */


		Customer customer = new Customer();
		int customerId = -1;
		int accountId = -1;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");
			Statement stmt = con.createStatement();

			String SQL = ("SELECT `AccountId`, COUNT(`AccountId`) AS `max` FROM `rental` GROUP BY `AccountId` ORDER BY `max` DESC LIMIT 1");
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				accountId = rs.getInt("AccountId");
			}
			
			SQL = ("SELECT account.Customer FROM `account` WHERE account.Id = \'" + accountId + "\'");
			ResultSet rsCustId = stmt.executeQuery(SQL);
			while(rsCustId.next())
			{
				customerId = rsCustId.getInt("Customer");
			}
			SQL = ("SELECT person.FirstName, person.LastName, person.Email FROM `person`, `customer` WHERE person.SSN = \'" + customerId + "\'");
			ResultSet rs2 = stmt.executeQuery(SQL);
			while(rs2.next()) {
				customer.setCustomerID(customerId);
				customer.setFirstName(rs2.getString("FirstName"));
				customer.setLastName(rs2.getString("LastName"));
				customer.setEmail(rs2.getString("Email"));
			}
		return customer;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	
	}

	public List<Customer> getCustomerMailingList() {

		/*
		 * This method fetches the all customer mailing details and returns it The
		 * students code to fetch data from the database will be written here Each
		 * customer record is required to be encapsulated as a "Customer" class object
		 * and added to the "customers" List
		 */

		List<Customer> customers = new ArrayList<Customer>();

		// Necessary for jdbc driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return null;
		}

		// Create a connection to the SQL server and query matches for username and
		// password
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb?useSSL=false", "root",
				"root"); Statement stmt = con.createStatement();) {
			String SQL = ("SELECT CustId FROM customer");
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				customers.add(getCustomer(rs.getInt("CustId")));
			}
			rs.close();
			return customers;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}

	}

	public Customer getCustomer(int customerID) {

		/*
		 * This method fetches the customer details and returns it customerID, which is
		 * the Customer's ID who's details have to be fetched, is given as method
		 * parameter The students code to fetch data from the database will be written
		 * here The customer record is required to be encapsulated as a "Customer" class
		 * object
		 */
		Customer customer = new Customer();

		// Necessary for jdbc driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return null;
		}

		// Create a connection to the SQL server hand query matches for username and
		// password
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb?useSSL=false", "root", "root");
				Statement stmt = con.createStatement();) {
			String SQL = ("SELECT * FROM customer where CustId like \'%" + customerID + "%\'");
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				// If a match is found update known values and continue query
				customer.setCustomerID(customerID);
				customer.setEmail(rs.getString("Email"));
				customer.setRating(rs.getInt("Rating"));
				customer.setCreditCard(rs.getString("CreditCardNumber"));

				SQL = ("SELECT * FROM person where SSN like \'%" + customer.getCustomerID() + "%\'");
				Statement stmt2 = con.createStatement();
				ResultSet rs2 = stmt2.executeQuery(SQL);
				while (rs2.next()) {
					// If a match is found update known values and continue query
					customer.setFirstName(rs2.getString("FirstName"));
					customer.setLastName(rs2.getString("LastName"));
					customer.setAddress(rs2.getString("Address"));
					customer.setZipCode(rs2.getInt("ZipCode"));
					customer.setEmail(rs2.getString("Email"));
					customer.setTelephone(rs2.getString("Telephone"));

					SQL = ("SELECT * FROM location where ZipCode like \'%" + customer.getZipCode() + "%\'");
					Statement stmt3 = con.createStatement();
					ResultSet rs3 = stmt3.executeQuery(SQL);
					while (rs3.next()) {
						// If a match is found update known values and continue query
						customer.setCity(rs3.getString("City"));
						customer.setState(rs3.getString("State"));
						return customer;
					}
					rs3.close();
				}
				rs2.close();
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}

		// If no matches are found, invalid credentials
		return null;
	}
		
	
	public int deleteCustomer(int customerID) {

		/*
		 * This method deletes a customer returns "success" string on success, else
		 * returns "failure" The students code to delete the data from the database will
		 * be written here customerID, which is the Customer's ID who's details have to
		 * be deleted, is given as method parameter
		 */
		// Necessary for jdbc driver
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return -1;
		}

		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb?useSSL=false", "root",
				"root"); Statement stmt = con.createStatement();) {

			String SQL = ("DELETE customer, login FROM customer INNER JOIN login on customer.Email = login.username where CustId like " + customerID);
			stmt.executeUpdate(SQL);
			SQL = ("DELETE person, location FROM person INNER JOIN location on person.ZipCode = location.ZipCode AND person.Address = location.Address where SSN like " + customerID);
			stmt.executeUpdate(SQL);
		} catch (SQLException e) {
			e.printStackTrace();
			return -1;
		}
		return 0;

	}


	public int getCustomerID(String username) {
		
		/*
		 * This method returns the Customer's ID based on the provided email address
		 * The students code to fetch data from the database will be written here
		 * username, which is the email address of the customer, who's ID has to be returned, is given as method parameter
		 * The Customer's ID is required to be returned as a String
		 */
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return -1;
		} 
		
		//Create a connection to the SQL server and query matches for username and password
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb?useSSL=false", "root", "root");
                Statement stmt = con.createStatement();) {
            String SQL = ("SELECT CustId FROM customer WHERE customer.Email = '" + username + "'");
            ResultSet rs = stmt.executeQuery(SQL);
            int CustId = -1;
            while(rs.next()) {
            	CustId = rs.getInt("CustId");
            }
            return CustId;
            } catch (SQLException e) {
                e.printStackTrace();
                return -1;
            }
	}


	public List<Customer> getSellers() {
		
		/*
		 * This method fetches the all seller details and returns it
		 * The students code to fetch data from the database will be written here
		 * The seller (which is a customer) record is required to be encapsulated as a "Customer" class object and added to the "customers" List
		 */

		List<Customer> customers = new ArrayList<Customer>();
		
		/*Sample data begins*/
		for (int i = 0; i < 10; i++) {
			Customer customer = new Customer();
			customer.setCustomerID(111-11-1111);
			customer.setAddress("123 Success Street");
			customer.setLastName("Lu");
			customer.setFirstName("Shiyong");
			customer.setCity("Stony Brook");
			customer.setState("NY");
			customer.setEmail("shiyong@cs.sunysb.edu");
			customer.setZipCode(11790);
			customers.add(customer);			
		}
		/*Sample data ends*/
		
		return customers;

	}


	public String addCustomer(Customer customer) {

		/*
		 * All the values of the add customer form are encapsulated in the customer
		 * object. These can be accessed by getter methods (see Customer class in model
		 * package). e.g. firstName can be accessed by customer.getFirstName() method.
		 * The sample code returns "success" by default. You need to handle the database
		 * insertion of the customer details and return "success" or "failure" based on
		 * result of the database insertion.
		 */
		// Person Table
		int SSN = customer.getCustomerID();
		String firstName = customer.getFirstName();
		String lastName = customer.getLastName();
		String telephone = customer.getTelephone();

		// Location Table
		String address = customer.getAddress();
		String city = customer.getCity();
		String state = customer.getState();
		int zipCode = customer.getZipCode();

		// customer Table
		int customerID = customer.getCustomerID();
		String email = customer.getEmail();
		int rating = customer.getRating();
		String creditCardNum = customer.getCreditCard();
		// account Table
		LocalDate today = LocalDate.now();
		String openedDate = today.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
		CustomerDao customerd = new CustomerDao();
		int aId = customerd.findCustId(customer);
		String plan = "Limited";
		// Necessary for jdbc driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return "failure";
		}

		// Create a connection to the SQL server and insert customer
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb?useSSL=false", "root", "root");
			PreparedStatement pstmt = con
					.prepareStatement("INSERT INTO `location`(ZipCode,City,State,Address) VALUE (?,?,?,?)");
			pstmt.setInt(1, zipCode);
			pstmt.setString(2, city);
			pstmt.setString(3, state);
			pstmt.setString(4, address);
			pstmt.executeUpdate();

			pstmt = con.prepareStatement(
					"INSERT INTO `person`(SSN,LastName,FirstName,Address,ZipCode,Telephone,Email) VALUE (?,?,?,?,?,?,?)");
			pstmt.setInt(1, SSN);
			pstmt.setString(2, lastName);
			pstmt.setString(3, firstName);
			pstmt.setString(4, address);
			pstmt.setInt(5, zipCode);
			pstmt.setString(6, telephone);
			pstmt.setString(7, email);
			pstmt.executeUpdate();

			pstmt = con.prepareStatement("INSERT INTO `customer`(CustID,Email,Rating,CreditCardNumber) VALUE (?,?,?,?)");
			pstmt.setInt(1, customerID);
			pstmt.setString(2, email);
			pstmt.setInt(3, rating);
			pstmt.setString(4, creditCardNum);
			pstmt.executeUpdate();
			
			pstmt = con.prepareStatement("INSERT INTO `account`(Id,DateOpened,Type,Customer) VALUE (?,?,?,?)");
			pstmt.setInt(1, aId);
			pstmt.setString(2, openedDate);
			pstmt.setString(3, plan);
			pstmt.setInt(4, customerID);
			pstmt.executeUpdate();

			return "success";

		} catch (SQLException e) {
			e.printStackTrace();
			return "failure";
		}

	}


	public int findCustId(Customer customer)
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");
			
			String SQLforMaxId = "SELECT MAX(Id) AS max FROM `account`";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(SQLforMaxId);
			int maxId = 0;
            while (rs.next())
            {
            	maxId = rs.getInt("max");
            }
            return maxId + 1;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
	}

	public String editCustomer(Customer customer) {
		/*
		 * All the values of the edit customer form are encapsulated in the customer
		 * object. These can be accessed by getter methods (see Customer class in model
		 * package). e.g. firstName can be accessed by customer.getFirstName() method.
		 * The sample code returns "success" by default. You need to handle the database
		 * update and return "success" or "failure" based on result of the database
		 * update.
		 */

		// Person Table
		int SSN = customer.getCustomerID();
		String firstName = customer.getFirstName();
		String lastName = customer.getLastName();
		String telephone = customer.getTelephone();

		// Location Table
		String address = customer.getAddress();
		String city = customer.getCity();
		String state = customer.getState();
		int zipCode = customer.getZipCode();

		// customer Table
		int customerID = customer.getCustomerID();
		String email = customer.getEmail();
		int rating = customer.getRating();
		String creditCardNum = customer.getCreditCard();

		// Necessary for jdbc driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return "failure";
		}

		// Create a connection to the SQL server and insert customer
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb?useSSL=false", "root","root"); Statement stmt = con.createStatement();) {
			String SQL = ("UPDATE person, location, customer SET person.FirstName = \'" + firstName + "\', person.LastName = \'" + lastName + "\', person.Telephone = \'"+ telephone +"\', person.Email = \'" + email +"\', person.Address = \'" + address +"\', "
					+ "location.Address = \'" + address + "\', location.City = \'" + city + "\', location.State = \'" + state + "\', location.ZipCode = \'" + zipCode + "\',"
					+ "customer.Email = \'" + email + "\', customer.Rating = \'" + rating + "\', customer.CreditCardNumber = \'" + creditCardNum + "\' "
					+ "where SSN like \'" + customerID + "\' AND location.ZipCode = person.ZipCode");
			stmt.executeUpdate(SQL);
			return "success";

		} catch (SQLException e) {
			e.printStackTrace();
			return "failure";
		}

	}

}
