package dao;

public class AppearedInDao {

}
