package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Customer;
import model.Employee;

public class EmployeeDao {
    /*
	 * This class handles all the database operations related to the employee table
	 */
	
	public String addEmployee(Employee employee) {

		/*
		 * All the values of the add employee form are encapsulated in the employee object.
		 * These can be accessed by getter methods (see Employee class in model package).
		 * e.g. firstName can be accessed by employee.getFirstName() method.
		 * The sample code returns "success" by default.
		 * You need to handle the database insertion of the employee details and return "success" or "failure" based on result of the database insertion.
		 */
		
		//Extract data from Employee
		//Person Table
		int SSN = employee.getEmployeeID();
		String firstName = employee.getFirstName();
		String lastName = employee.getLastName();
		String email = employee.getEmail();
		String telephone = employee.getTelephone();
		
		//Location Table
		String address = employee.getAddress();
		String city = employee.getCity();
		String state = employee.getState();
		int zipCode = employee.getZipCode();
		
		//Employee Table
		int employeeID = employee.getEmployeeID();
		String startDate = employee.getStartDate();
		float hourlyRate = employee.getHourlyRate();
		String revenue = employee.getRevenue();
		
		//Necessary for jdbc driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return "failure";
		} 
		
		//Create a connection to the SQL server and insert employee
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");
			PreparedStatement pstmt = con.prepareStatement("INSERT INTO `location`(ZipCode,City,State,Address) VALUE (?,?,?,?)");
			pstmt.setInt(1, zipCode );
			pstmt.setString(2, city);
			pstmt.setString(3, state);
			pstmt.setString(4, address);
			pstmt.executeUpdate();
			
			pstmt = con.prepareStatement("INSERT INTO `person`(SSN,LastName,FirstName,Address,ZipCode,Telephone,Email) VALUE (?,?,?,?,?,?,?)");
			pstmt.setInt(1, SSN );
			pstmt.setString(2, lastName);
			pstmt.setString(3, firstName);
			pstmt.setString(4, address);
			pstmt.setInt(5, zipCode);
			pstmt.setString(6, telephone);
			pstmt.setString(7, email);
			pstmt.executeUpdate();
			
			
			pstmt = con.prepareStatement("INSERT INTO `employee`(EmpId,SSN,StartDate,HourlyRate,revenue) VALUE (?,?,?,?,?)");
			pstmt.setInt(1, employeeID );
			pstmt.setInt(2, SSN);
			pstmt.setString(3, startDate);
			pstmt.setFloat(4, hourlyRate);
			pstmt.setString(5, revenue);
			pstmt.executeUpdate();
			
			System.out.print(SSN);
			
            return "success";
            
		} catch (SQLException e) {
            e.printStackTrace();
            return "failure";
        }

	}

	public String editEmployee(Employee employee) {
		/*
		 * All the values of the edit employee form are encapsulated in the employee object.
		 * These can be accessed by getter methods (see Employee class in model package).
		 * e.g. firstName can be accessed by employee.getFirstName() method.
		 * The sample code returns "success" by default.
		 * You need to handle the database update and return "success" or "failure" based on result of the database update.
		 */
		
		// Person Table
		String firstName = employee.getFirstName();
		String lastName = employee.getLastName();
		String telephone = employee.getTelephone();

		// Location Table
		String address = employee.getAddress();
		String city = employee.getCity();
		String state = employee.getState();
		int zipCode = employee.getZipCode();

		// customer Table
		int employeeID = employee.getEmployeeID();
		String email = employee.getEmail();
		String startDate = employee.getStartDate();
		float hourlyRate = employee.getHourlyRate();

		// Necessary for jdbc driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return "failure";
		}

		// Create a connection to the SQL server and insert customer
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb?useSSL=false", "root","root"); Statement stmt = con.createStatement();) {
			String SQL = ("UPDATE person, location, employee SET person.FirstName = \'" + firstName + "\', person.LastName = \'" + lastName + "\', person.Telephone = \'"+ telephone +"\', person.Email = \'" + email +"\', person.Address = \'" + address +"\', "
					+ "location.Address = \'" + address + "\', location.City = \'" + city + "\', location.State = \'" + state + "\', location.ZipCode = \'" + zipCode + "\', "
					+ "employee.StartDate = \'" + startDate + "\', employee.HourlyRate = \'" + hourlyRate + "\' "
					+ "where person.SSN like \'" + employeeID + "\' AND location.ZipCode = person.ZipCode");
			stmt.executeUpdate(SQL);
			return "success";

		} catch (SQLException e) {
			e.printStackTrace();
			return "failure";
		}

	}

	public String deleteEmployee(String employeeID) {
		/*
		 * employeeID, which is the Employee's ID which has to be deleted, is given as method parameter
		 * The sample code returns "success" by default.
		 * You need to handle the database deletion and return "success" or "failure" based on result of the database deletion.
		 */
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return "failure";
		}

		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb?useSSL=false", "root",
				"root"); Statement stmt = con.createStatement();) {

			String SQL = ("DELETE FROM employee where EmpId like " + employeeID);
			stmt.executeUpdate(SQL);
//			SQL = ("DELETE person, location FROM person INNER JOIN location on person.ZipCode = location.ZipCode AND person.Address = location.Address where SSN like " + customerID);
//			stmt.executeUpdate(SQL);
		} catch (SQLException e) {
			e.printStackTrace();
			return "failure";
		}
		return "failure";
	}

	//fix error where empty rows are displayed
	public List<Employee> getEmployees() {

		/*
		 * The students code to fetch data from the database will be written here
		 * Query to return details about all the employees must be implemented
		 * Each record is required to be encapsulated as a "Employee" class object and added to the "employees" List
		 */

		List<Employee> employees = new ArrayList<Employee>();
		
		//Necessary for jdbc driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return null;
		} 
		
		//Create a connection to the SQL server and query matches for username and password
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");
                Statement stmt = con.createStatement();) {
            String SQL = ("SELECT EmpID FROM employee");
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
            	employees.add(getEmployee(rs.getInt("EmpId")));       	
            }
            return employees;
            } catch (SQLException e) {
                e.printStackTrace();
                return null;
            }
	}

	public Employee getEmployee(int employeeID) {

		/*
		 * The students code to fetch data from the database based on "employeeID" will be written here
		 * employeeID, which is the Employee's ID who's details have to be fetched, is given as method parameter
		 * The record is required to be encapsulated as a "Employee" class object
		 */

		Employee employee = new Employee();
		//Necessary for jdbc driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return null;
		} 
		
		//Create a connection to the SQL server and query matches for username and password
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");
                Statement stmt = con.createStatement();) {
            String SQL = ("SELECT * FROM employee where EmpId like \'%" + employeeID + "%\'");
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
            	//If a match is found update known values and continue query
            	employee.setEmployeeID(employeeID);
            	employee.setSSN(rs.getInt("SSN"));
            	employee.setStartDate(rs.getString("StartDate"));
            	employee.setHourlyRate(rs.getFloat("HourlyRate"));
            	employee.setRevenue(rs.getString("revenue"));
            	
            	SQL = ("SELECT * FROM person where SSN like \'%" + employee.getSSN() + "%\'");
            	Statement stmt2 = con.createStatement();
            	ResultSet rs2 = stmt2.executeQuery(SQL);
            	while(rs2.next())
            	{
            		//If a match is found update known values and continue query
            		employee.setFirstName(rs2.getString("FirstName"));
            		employee.setLastName(rs2.getString("LastName"));
            		employee.setAddress(rs2.getString("Address"));
            		employee.setZipCode(rs2.getInt("ZipCode"));
            		employee.setEmail(rs2.getString("Email"));
            		employee.setTelephone(rs2.getString("Telephone"));
            		
            		SQL = ("SELECT * FROM location where ZipCode like \'%" + employee.getZipCode() + "%\'");
                	Statement stmt3 = con.createStatement();
                	ResultSet rs3 = stmt3.executeQuery(SQL);
                	while(rs3.next())
                	{
                		//If a match is found update known values and continue query
                		employee.setCity(rs3.getString("City"));
                		employee.setState(rs3.getString("State"));
                		return employee;
                	}
            	}
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
		
		//If no matches are found, invalid credentials
		return null;
	}
	
	public Employee getHighestRevenueEmployee() {
		
		/*
		 * The students code to fetch employee data who generated the highest revenue will be written here
		 * The record is required to be encapsulated as a "Employee" class object
		 */

		Employee employee = new Employee();
		int employeeId = -1;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");
			Statement stmt = con.createStatement();

			String SQL = ("SELECT CustRepId, COUNT(*) AS magnitude FROM rental Limit 1");
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
				employeeId = rs.getInt("CustRepId");
				employee.setEmployeeID(employeeId);
			}
			SQL = ("SELECT person.FirstName, person.LastName, person.Email FROM person WHERE person.SSN = \'" + employeeId + "\'");
			ResultSet rs2 = stmt.executeQuery(SQL);
			while(rs2.next()) {
				employee.setFirstName(rs2.getString("FirstName"));
				employee.setLastName(rs2.getString("LastName"));
				employee.setEmail(rs2.getString("Email"));
			}
		return employee;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public int getEmployeeID(String username) {
		/*
		 * The students code to fetch data from the database based on "username" will be written here
		 * username, which is the Employee's email address who's Employee ID has to be fetched, is given as method parameter
		 * The Employee ID is required to be returned as a String
		 */
		
		//Necessary for jdbc driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return -1;
		} 
		
		//Create a connection to the SQL server and query
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");
			String SQL = ("SELECT SSN FROM person where email like \'%" + username + "%\'");
			Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL); //rs = SSN of employee
            while(rs.next())
            {
            	SQL = ("SELECT EmpId FROM employee where SSN like \'%" + rs.getString("SSN") + "%\'");
            	Statement stmt2 = con.createStatement();
            	ResultSet rs2 = stmt2.executeQuery(SQL);//rs2 = EmpId
            	while(rs2.next())
            	{
            		return rs2.getInt("EmpId");
            	}
            	
            }
            
		} catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
		
		return -1;

	}
}