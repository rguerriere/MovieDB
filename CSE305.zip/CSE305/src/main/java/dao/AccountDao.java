package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Employee;
import model.Movie;
import model.Account;

public class AccountDao {
    
	public int getSalesReport(Account account) {

		/*
		 * The students code to fetch data from the database will be written here Query
		 * to get sales report for a particular month must be implemented account, which
		 * has details about the month and year for which the sales report is to be
		 * generated, is given as method parameter The month and year are in the format
		 * "month-year", e.g. "10-2018" and stored in the dateOpened attribute of
		 * account object The month and year can be accessed by getter method, i.e.,
		 * account.getAcctCreateDate()
		 */

		int income = 0;
		String dateToQuery = account.getAcctCreateDate();
		dateToQuery.substring(0, 6);
		System.out.println("Date to Query" + dateToQuery);
		String[] dateToQueryVals = dateToQuery.split("-");

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root", "root");
			String SQL = "SELECT * FROM account";
			PreparedStatement stmt = con.prepareStatement(SQL);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				String dateToCheck = rs.getString("dateOpened").substring(0, 7);
				dateToCheck = dateToCheck.substring(5, 7) + "-" + dateToCheck.substring(0, 4);
				String[] dateToCheckVals = dateToCheck.split("-");

				if (dateToQueryVals[1].compareTo(dateToCheckVals[1]) > 0) {
					if (rs.getString("Type").equalsIgnoreCase("limited")) {
						income += 10;
						System.out.println("Income: " + income);
					} else if (rs.getString("Type").equalsIgnoreCase("unlimited-1")) {
						income += 15;
						System.out.println("Income: " + income);
					} else if (rs.getString("Type").equalsIgnoreCase("unlimited-2")) {
						income += 20;
						System.out.println("Income: " + income);
					} else if (rs.getString("Type").equalsIgnoreCase("unlimited-3")) {
						income += 25;
						System.out.println("Income: " + income);
					} else
						income += 0;
				} else if (dateToQueryVals[1].compareTo(dateToCheckVals[1]) == 0) {
					if (dateToQueryVals[0].compareTo(dateToCheckVals[0]) >= 0) {
						if (rs.getString("Type").equalsIgnoreCase("limited")) {
							income += 10;
							System.out.println("Income: " + income);
						} else if (rs.getString("Type").equalsIgnoreCase("unlimited-1")) {
							income += 15;
							System.out.println("Income: " + income);
						} else if (rs.getString("Type").equalsIgnoreCase("unlimited-2")) {
							income += 20;
							System.out.println("Income: " + income);
						} else if (rs.getString("Type").equalsIgnoreCase("unlimited-3")) {
							income += 25;
							System.out.println("Income: " + income);
						} else
							income += 0;
					}
				}
			}
			return income;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}
	
	public String setAccount(String customerID, String accountType) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return null;
		} 
		
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root",
				"root"); Statement stmt = con.createStatement();) {
			
			String SQL = ("UPDATE account "
					+ "SET Type = '" + accountType +"'"
					+ " WHERE Customer = '" + customerID +"'");
			stmt.execute(SQL);
			
//			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		} catch (NullPointerException e) {
			e.printStackTrace();
			return null;
		}

		
		/*Sample data begins*/
		return "success";
		/*Sample data ends*/

	}
	

}