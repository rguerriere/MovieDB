package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Movie;
import model.Rental;

public class RentalDao {
    
	public List<Rental> getOrderHisroty(String customerID) {
		
		List<Rental> rentals = new ArrayList<Rental>();
			
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			return null;
		} 
		
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root",
				"root"); Statement stmt = con.createStatement();) {
			
			String SQL = ("SELECT rental.orderID, rental.movieId, rental.CustRepId, order.dateTime, order.returnDate "
					+ "FROM `account`, `rental`, `order` "
					+ "WHERE account.Id = rental.AccountId AND rental.orderID = order.Id AND account.customer = " + customerID);
			ResultSet rs = stmt.executeQuery(SQL);
			while (rs.next()) {
	        	
				Rental rental = new Rental();
				int tempOrder = rs.getInt("rental.orderID");
				int tempMovie = rs.getInt("rental.movieId");
				int tempCust = rs.getInt("rental.CustRepId");
				int tempInt = 0;
//				for(int i = 0;i < movies.size(); i++) {
//					if(movies.get(i).getMovieType().equals(temp))
//						tempInt ++;
//				}
				if(tempInt == 0) 
				{
					rental.setOrderID(tempOrder);
					rental.setMovieID(tempMovie);
					rental.setCustomerRepID(tempCust);
					rentals.add(rental);
				}
	        }
			
//			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
						
		return rentals;
		
	}

}